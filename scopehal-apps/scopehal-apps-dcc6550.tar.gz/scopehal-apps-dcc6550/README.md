# scopehal-apps

Applications for libscopehal

[C++ coding policy](https://github.com/azonenberg/coding-policy/blob/master/cpp-coding-policy.md)

## Installation

Refer to the "getting started" chapter of [the manual](https://www.antikernel.net/temp/glscopeclient-manual.pdf).
