# xptools
Cross-platform helper classes/functions too small to deserve their own library. Requires logtools.

Originally developed for libztools and Antikernel and now moved to a separate repo for easier re-use.

This project is not intended to be compiled and installed by itself since it's so simple; it's normally pulled into a larger 
project as a Git submodule and then built by that project's build system.

A simple leaf CMakeLists.txt is provided to ease integration with parent projects.
